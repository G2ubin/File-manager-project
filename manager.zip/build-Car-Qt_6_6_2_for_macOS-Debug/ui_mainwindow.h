/********************************************************************************
** Form generated from reading UI file 'mainwindow.ui'
**
** Created by: Qt User Interface Compiler version 6.6.2
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_MAINWINDOW_H
#define UI_MAINWINDOW_H

#include <QtCore/QVariant>
#include <QtWidgets/QApplication>
#include <QtWidgets/QHBoxLayout>
#include <QtWidgets/QHeaderView>
#include <QtWidgets/QLabel>
#include <QtWidgets/QLineEdit>
#include <QtWidgets/QMainWindow>
#include <QtWidgets/QMenuBar>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QSpinBox>
#include <QtWidgets/QStatusBar>
#include <QtWidgets/QTableWidget>
#include <QtWidgets/QVBoxLayout>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui_MainWindow
{
public:
    QWidget *centralwidget;
    QWidget *verticalLayoutWidget;
    QVBoxLayout *verticalLayout;
    QTableWidget *tableWidget;
    QPushButton *pushButton;
    QLineEdit *lineEdit;
    QTableWidget *manufacturerTable;
    QPushButton *generateCarsByTypeButton;
    QLineEdit *lineEditBodyType;
    QTableWidget *carsByTypeTable;
    QTableWidget *carsByPriceRangeTable;
    QPushButton *btnGenerateByPriceRange;
    QSpinBox *spinBoxMinPrice;
    QSpinBox *spinBoxMaxPrice;
    QLabel *label;
    QLabel *label_2;
    QWidget *horizontalLayoutWidget;
    QHBoxLayout *horizontalLayout;
    QPushButton *onLoadFile;
    QPushButton *CreateFile;
    QMenuBar *menubar;
    QStatusBar *statusbar;

    void setupUi(QMainWindow *MainWindow)
    {
        if (MainWindow->objectName().isEmpty())
            MainWindow->setObjectName("MainWindow");
        MainWindow->resize(1365, 800);
        MainWindow->setAnimated(true);
        centralwidget = new QWidget(MainWindow);
        centralwidget->setObjectName("centralwidget");
        verticalLayoutWidget = new QWidget(centralwidget);
        verticalLayoutWidget->setObjectName("verticalLayoutWidget");
        verticalLayoutWidget->setGeometry(QRect(40, 460, 211, 81));
        verticalLayout = new QVBoxLayout(verticalLayoutWidget);
        verticalLayout->setObjectName("verticalLayout");
        verticalLayout->setContentsMargins(0, 0, 0, 0);
        tableWidget = new QTableWidget(centralwidget);
        tableWidget->setObjectName("tableWidget");
        tableWidget->setGeometry(QRect(20, 20, 661, 461));
        pushButton = new QPushButton(centralwidget);
        pushButton->setObjectName("pushButton");
        pushButton->setGeometry(QRect(1140, 20, 221, 51));
        QFont font;
        font.setFamilies({QString::fromUtf8("Helvetica Neue")});
        font.setBold(true);
        pushButton->setFont(font);
        lineEdit = new QLineEdit(centralwidget);
        lineEdit->setObjectName("lineEdit");
        lineEdit->setGeometry(QRect(1140, 80, 221, 31));
        manufacturerTable = new QTableWidget(centralwidget);
        manufacturerTable->setObjectName("manufacturerTable");
        manufacturerTable->setGeometry(QRect(700, 20, 431, 231));
        generateCarsByTypeButton = new QPushButton(centralwidget);
        generateCarsByTypeButton->setObjectName("generateCarsByTypeButton");
        generateCarsByTypeButton->setGeometry(QRect(1140, 260, 221, 51));
        generateCarsByTypeButton->setFont(font);
        lineEditBodyType = new QLineEdit(centralwidget);
        lineEditBodyType->setObjectName("lineEditBodyType");
        lineEditBodyType->setGeometry(QRect(1140, 320, 221, 31));
        carsByTypeTable = new QTableWidget(centralwidget);
        carsByTypeTable->setObjectName("carsByTypeTable");
        carsByTypeTable->setGeometry(QRect(700, 260, 431, 231));
        carsByPriceRangeTable = new QTableWidget(centralwidget);
        carsByPriceRangeTable->setObjectName("carsByPriceRangeTable");
        carsByPriceRangeTable->setGeometry(QRect(700, 500, 431, 231));
        btnGenerateByPriceRange = new QPushButton(centralwidget);
        btnGenerateByPriceRange->setObjectName("btnGenerateByPriceRange");
        btnGenerateByPriceRange->setGeometry(QRect(1140, 500, 221, 51));
        btnGenerateByPriceRange->setFont(font);
        spinBoxMinPrice = new QSpinBox(centralwidget);
        spinBoxMinPrice->setObjectName("spinBoxMinPrice");
        spinBoxMinPrice->setGeometry(QRect(1140, 560, 101, 31));
        spinBoxMaxPrice = new QSpinBox(centralwidget);
        spinBoxMaxPrice->setObjectName("spinBoxMaxPrice");
        spinBoxMaxPrice->setGeometry(QRect(1140, 600, 101, 31));
        label = new QLabel(centralwidget);
        label->setObjectName("label");
        label->setGeometry(QRect(1250, 564, 31, 21));
        label->setFont(font);
        label->setAutoFillBackground(false);
        label->setFrameShadow(QFrame::Raised);
        label->setLineWidth(2);
        label_2 = new QLabel(centralwidget);
        label_2->setObjectName("label_2");
        label_2->setGeometry(QRect(1254, 610, 31, 16));
        label_2->setFont(font);
        horizontalLayoutWidget = new QWidget(centralwidget);
        horizontalLayoutWidget->setObjectName("horizontalLayoutWidget");
        horizontalLayoutWidget->setGeometry(QRect(260, 460, 231, 81));
        horizontalLayout = new QHBoxLayout(horizontalLayoutWidget);
        horizontalLayout->setObjectName("horizontalLayout");
        horizontalLayout->setContentsMargins(0, 0, 0, 0);
        onLoadFile = new QPushButton(centralwidget);
        onLoadFile->setObjectName("onLoadFile");
        onLoadFile->setGeometry(QRect(510, 490, 171, 51));
        QFont font1;
        font1.setFamilies({QString::fromUtf8("Helvetica Neue")});
        font1.setPointSize(14);
        font1.setBold(true);
        font1.setItalic(true);
        onLoadFile->setFont(font1);
        CreateFile = new QPushButton(centralwidget);
        CreateFile->setObjectName("CreateFile");
        CreateFile->setGeometry(QRect(510, 550, 171, 51));
        CreateFile->setFont(font1);
        MainWindow->setCentralWidget(centralwidget);
        menubar = new QMenuBar(MainWindow);
        menubar->setObjectName("menubar");
        menubar->setGeometry(QRect(0, 0, 1365, 24));
        MainWindow->setMenuBar(menubar);
        statusbar = new QStatusBar(MainWindow);
        statusbar->setObjectName("statusbar");
        MainWindow->setStatusBar(statusbar);

        retranslateUi(MainWindow);

        QMetaObject::connectSlotsByName(MainWindow);
    } // setupUi

    void retranslateUi(QMainWindow *MainWindow)
    {
        MainWindow->setWindowTitle(QCoreApplication::translate("MainWindow", "MainWindow", nullptr));
        pushButton->setText(QCoreApplication::translate("MainWindow", "\320\241\320\277\320\270\321\201\320\276\320\272 \320\277\320\276 \321\204\320\270\321\200\320\274\320\265 ", nullptr));
        lineEdit->setText(QString());
        generateCarsByTypeButton->setText(QCoreApplication::translate("MainWindow", "\320\241\320\277\320\270\321\201\320\276\320\272 \320\277\320\276 \320\272\321\203\320\267\320\276\320\262\321\203", nullptr));
        btnGenerateByPriceRange->setText(QCoreApplication::translate("MainWindow", "\320\241\320\277\320\270\321\201\320\276\320\272 \320\277\320\276 \321\206\320\265\320\275\320\265", nullptr));
        label->setText(QCoreApplication::translate("MainWindow", " Min", nullptr));
        label_2->setText(QCoreApplication::translate("MainWindow", "Max", nullptr));
        onLoadFile->setText(QCoreApplication::translate("MainWindow", "\320\227\320\260\320\263\321\200\321\203\320\267\320\270\321\202\321\214 \320\264\320\260\320\275\320\275\321\213\320\265", nullptr));
        CreateFile->setText(QCoreApplication::translate("MainWindow", "\320\241\320\276\320\267\320\264\320\260\321\202\321\214 \321\204\320\260\320\271\320\273", nullptr));
    } // retranslateUi

};

namespace Ui {
    class MainWindow: public Ui_MainWindow {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_MAINWINDOW_H
