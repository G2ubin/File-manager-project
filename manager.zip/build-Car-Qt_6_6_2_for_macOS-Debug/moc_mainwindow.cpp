/****************************************************************************
** Meta object code from reading C++ file 'mainwindow.h'
**
** Created by: The Qt Meta Object Compiler version 68 (Qt 6.6.2)
**
** WARNING! All changes made in this file will be lost!
*****************************************************************************/

#include "../Car/mainwindow.h"
#include <QtCore/qmetatype.h>

#if __has_include(<QtCore/qtmochelpers.h>)
#include <QtCore/qtmochelpers.h>
#else
QT_BEGIN_MOC_NAMESPACE
#endif


#include <memory>

#if !defined(Q_MOC_OUTPUT_REVISION)
#error "The header file 'mainwindow.h' doesn't include <QObject>."
#elif Q_MOC_OUTPUT_REVISION != 68
#error "This file was generated using the moc from 6.6.2. It"
#error "cannot be used with the include files from this version of Qt."
#error "(The moc has changed too much.)"
#endif

#ifndef Q_CONSTINIT
#define Q_CONSTINIT
#endif

QT_WARNING_PUSH
QT_WARNING_DISABLE_DEPRECATED
QT_WARNING_DISABLE_GCC("-Wuseless-cast")
namespace {

#ifdef QT_MOC_HAS_STRINGDATA
struct qt_meta_stringdata_CLASSMainWindowENDCLASS_t {};
constexpr auto qt_meta_stringdata_CLASSMainWindowENDCLASS = QtMocHelpers::stringData(
    "MainWindow",
    "checkPriceInput",
    "",
    "QTableWidgetItem*",
    "item",
    "checkTypeInput",
    "addRow",
    "onRemoveRowButtonClicked",
    "saveData",
    "Update",
    "loadData",
    "filePath",
    "loadDataFile",
    "fileName",
    "QTableWidget*",
    "tableWidget",
    "onLoadCustomDataButtonClicked",
    "generateTable",
    "generateFile",
    "generateCarsByType",
    "generateCarsByPriceRange",
    "selectFilePath",
    "selectBodyTypeFilePath",
    "selectPriceFilePath"
);
#else  // !QT_MOC_HAS_STRING_DATA
struct qt_meta_stringdata_CLASSMainWindowENDCLASS_t {
    uint offsetsAndSizes[48];
    char stringdata0[11];
    char stringdata1[16];
    char stringdata2[1];
    char stringdata3[18];
    char stringdata4[5];
    char stringdata5[15];
    char stringdata6[7];
    char stringdata7[25];
    char stringdata8[9];
    char stringdata9[7];
    char stringdata10[9];
    char stringdata11[9];
    char stringdata12[13];
    char stringdata13[9];
    char stringdata14[14];
    char stringdata15[12];
    char stringdata16[30];
    char stringdata17[14];
    char stringdata18[13];
    char stringdata19[19];
    char stringdata20[25];
    char stringdata21[15];
    char stringdata22[23];
    char stringdata23[20];
};
#define QT_MOC_LITERAL(ofs, len) \
    uint(sizeof(qt_meta_stringdata_CLASSMainWindowENDCLASS_t::offsetsAndSizes) + ofs), len 
Q_CONSTINIT static const qt_meta_stringdata_CLASSMainWindowENDCLASS_t qt_meta_stringdata_CLASSMainWindowENDCLASS = {
    {
        QT_MOC_LITERAL(0, 10),  // "MainWindow"
        QT_MOC_LITERAL(11, 15),  // "checkPriceInput"
        QT_MOC_LITERAL(27, 0),  // ""
        QT_MOC_LITERAL(28, 17),  // "QTableWidgetItem*"
        QT_MOC_LITERAL(46, 4),  // "item"
        QT_MOC_LITERAL(51, 14),  // "checkTypeInput"
        QT_MOC_LITERAL(66, 6),  // "addRow"
        QT_MOC_LITERAL(73, 24),  // "onRemoveRowButtonClicked"
        QT_MOC_LITERAL(98, 8),  // "saveData"
        QT_MOC_LITERAL(107, 6),  // "Update"
        QT_MOC_LITERAL(114, 8),  // "loadData"
        QT_MOC_LITERAL(123, 8),  // "filePath"
        QT_MOC_LITERAL(132, 12),  // "loadDataFile"
        QT_MOC_LITERAL(145, 8),  // "fileName"
        QT_MOC_LITERAL(154, 13),  // "QTableWidget*"
        QT_MOC_LITERAL(168, 11),  // "tableWidget"
        QT_MOC_LITERAL(180, 29),  // "onLoadCustomDataButtonClicked"
        QT_MOC_LITERAL(210, 13),  // "generateTable"
        QT_MOC_LITERAL(224, 12),  // "generateFile"
        QT_MOC_LITERAL(237, 18),  // "generateCarsByType"
        QT_MOC_LITERAL(256, 24),  // "generateCarsByPriceRange"
        QT_MOC_LITERAL(281, 14),  // "selectFilePath"
        QT_MOC_LITERAL(296, 22),  // "selectBodyTypeFilePath"
        QT_MOC_LITERAL(319, 19)   // "selectPriceFilePath"
    },
    "MainWindow",
    "checkPriceInput",
    "",
    "QTableWidgetItem*",
    "item",
    "checkTypeInput",
    "addRow",
    "onRemoveRowButtonClicked",
    "saveData",
    "Update",
    "loadData",
    "filePath",
    "loadDataFile",
    "fileName",
    "QTableWidget*",
    "tableWidget",
    "onLoadCustomDataButtonClicked",
    "generateTable",
    "generateFile",
    "generateCarsByType",
    "generateCarsByPriceRange",
    "selectFilePath",
    "selectBodyTypeFilePath",
    "selectPriceFilePath"
};
#undef QT_MOC_LITERAL
#endif // !QT_MOC_HAS_STRING_DATA
} // unnamed namespace

Q_CONSTINIT static const uint qt_meta_data_CLASSMainWindowENDCLASS[] = {

 // content:
      12,       // revision
       0,       // classname
       0,    0, // classinfo
      16,   14, // methods
       0,    0, // properties
       0,    0, // enums/sets
       0,    0, // constructors
       0,       // flags
       0,       // signalCount

 // slots: name, argc, parameters, tag, flags, initial metatype offsets
       1,    1,  110,    2, 0x08,    1 /* Private */,
       5,    1,  113,    2, 0x08,    3 /* Private */,
       6,    0,  116,    2, 0x08,    5 /* Private */,
       7,    0,  117,    2, 0x08,    6 /* Private */,
       8,    0,  118,    2, 0x08,    7 /* Private */,
       9,    0,  119,    2, 0x08,    8 /* Private */,
      10,    1,  120,    2, 0x08,    9 /* Private */,
      12,    2,  123,    2, 0x08,   11 /* Private */,
      16,    0,  128,    2, 0x08,   14 /* Private */,
      17,    0,  129,    2, 0x08,   15 /* Private */,
      18,    0,  130,    2, 0x08,   16 /* Private */,
      19,    0,  131,    2, 0x08,   17 /* Private */,
      20,    0,  132,    2, 0x08,   18 /* Private */,
      21,    0,  133,    2, 0x08,   19 /* Private */,
      22,    0,  134,    2, 0x08,   20 /* Private */,
      23,    0,  135,    2, 0x08,   21 /* Private */,

 // slots: parameters
    QMetaType::Void, 0x80000000 | 3,    4,
    QMetaType::Void, 0x80000000 | 3,    4,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void, QMetaType::QString,   11,
    QMetaType::Void, QMetaType::QString, 0x80000000 | 14,   13,   15,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,

       0        // eod
};

Q_CONSTINIT const QMetaObject MainWindow::staticMetaObject = { {
    QMetaObject::SuperData::link<QMainWindow::staticMetaObject>(),
    qt_meta_stringdata_CLASSMainWindowENDCLASS.offsetsAndSizes,
    qt_meta_data_CLASSMainWindowENDCLASS,
    qt_static_metacall,
    nullptr,
    qt_incomplete_metaTypeArray<qt_meta_stringdata_CLASSMainWindowENDCLASS_t,
        // Q_OBJECT / Q_GADGET
        QtPrivate::TypeAndForceComplete<MainWindow, std::true_type>,
        // method 'checkPriceInput'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        QtPrivate::TypeAndForceComplete<QTableWidgetItem *, std::false_type>,
        // method 'checkTypeInput'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        QtPrivate::TypeAndForceComplete<QTableWidgetItem *, std::false_type>,
        // method 'addRow'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'onRemoveRowButtonClicked'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'saveData'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'Update'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'loadData'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        QtPrivate::TypeAndForceComplete<const QString &, std::false_type>,
        // method 'loadDataFile'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        QtPrivate::TypeAndForceComplete<const QString &, std::false_type>,
        QtPrivate::TypeAndForceComplete<QTableWidget *, std::false_type>,
        // method 'onLoadCustomDataButtonClicked'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'generateTable'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'generateFile'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'generateCarsByType'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'generateCarsByPriceRange'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'selectFilePath'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'selectBodyTypeFilePath'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'selectPriceFilePath'
        QtPrivate::TypeAndForceComplete<void, std::false_type>
    >,
    nullptr
} };

void MainWindow::qt_static_metacall(QObject *_o, QMetaObject::Call _c, int _id, void **_a)
{
    if (_c == QMetaObject::InvokeMetaMethod) {
        auto *_t = static_cast<MainWindow *>(_o);
        (void)_t;
        switch (_id) {
        case 0: _t->checkPriceInput((*reinterpret_cast< std::add_pointer_t<QTableWidgetItem*>>(_a[1]))); break;
        case 1: _t->checkTypeInput((*reinterpret_cast< std::add_pointer_t<QTableWidgetItem*>>(_a[1]))); break;
        case 2: _t->addRow(); break;
        case 3: _t->onRemoveRowButtonClicked(); break;
        case 4: _t->saveData(); break;
        case 5: _t->Update(); break;
        case 6: _t->loadData((*reinterpret_cast< std::add_pointer_t<QString>>(_a[1]))); break;
        case 7: _t->loadDataFile((*reinterpret_cast< std::add_pointer_t<QString>>(_a[1])),(*reinterpret_cast< std::add_pointer_t<QTableWidget*>>(_a[2]))); break;
        case 8: _t->onLoadCustomDataButtonClicked(); break;
        case 9: _t->generateTable(); break;
        case 10: _t->generateFile(); break;
        case 11: _t->generateCarsByType(); break;
        case 12: _t->generateCarsByPriceRange(); break;
        case 13: _t->selectFilePath(); break;
        case 14: _t->selectBodyTypeFilePath(); break;
        case 15: _t->selectPriceFilePath(); break;
        default: ;
        }
    } else if (_c == QMetaObject::RegisterMethodArgumentMetaType) {
        switch (_id) {
        default: *reinterpret_cast<QMetaType *>(_a[0]) = QMetaType(); break;
        case 7:
            switch (*reinterpret_cast<int*>(_a[1])) {
            default: *reinterpret_cast<QMetaType *>(_a[0]) = QMetaType(); break;
            case 1:
                *reinterpret_cast<QMetaType *>(_a[0]) = QMetaType::fromType< QTableWidget* >(); break;
            }
            break;
        }
    }
}

const QMetaObject *MainWindow::metaObject() const
{
    return QObject::d_ptr->metaObject ? QObject::d_ptr->dynamicMetaObject() : &staticMetaObject;
}

void *MainWindow::qt_metacast(const char *_clname)
{
    if (!_clname) return nullptr;
    if (!strcmp(_clname, qt_meta_stringdata_CLASSMainWindowENDCLASS.stringdata0))
        return static_cast<void*>(this);
    return QMainWindow::qt_metacast(_clname);
}

int MainWindow::qt_metacall(QMetaObject::Call _c, int _id, void **_a)
{
    _id = QMainWindow::qt_metacall(_c, _id, _a);
    if (_id < 0)
        return _id;
    if (_c == QMetaObject::InvokeMetaMethod) {
        if (_id < 16)
            qt_static_metacall(this, _c, _id, _a);
        _id -= 16;
    } else if (_c == QMetaObject::RegisterMethodArgumentMetaType) {
        if (_id < 16)
            qt_static_metacall(this, _c, _id, _a);
        _id -= 16;
    }
    return _id;
}
QT_WARNING_POP
