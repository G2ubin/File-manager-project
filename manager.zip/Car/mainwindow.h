#ifndef MAINWINDOW_H
#define MAINWINDOW_H

#include <QMainWindow>
#include <QTableWidgetItem>

QT_BEGIN_NAMESPACE
namespace Ui {
class MainWindow;
}
QT_END_NAMESPACE

class MainWindow : public QMainWindow
{
    Q_OBJECT

public:
    MainWindow(QWidget *parent = nullptr);
    ~MainWindow();

private slots:
    void checkPriceInput(QTableWidgetItem *item);
    void checkTypeInput(QTableWidgetItem *item);

    void addRow(); // Добавление строки
    void onRemoveRowButtonClicked(); // Удаление строки

    void saveData(); // Слот для сохранения данных
    void Update(); // Обновление данных

    void loadData(const QString &filePath); // Загрузка данных в главную таблицу
    void loadDataFile(const QString &fileName, QTableWidget *tableWidget);
    void onLoadCustomDataButtonClicked();

    void generateTable();
    void generateFile(); // Создание файла с фирмой
    void generateCarsByType(); // Новый слот для генерации файла по типу кузова
    void generateCarsByPriceRange(); //

    void selectFilePath();
    void selectBodyTypeFilePath();
    void selectPriceFilePath();

private:
    Ui::MainWindow *ui;
    QString currentFilePath; // Путь к текущему файлу
    QString manufacturerFileName; // Переменная для хранения имени файла
    QString bodyTypeFileName;
    QString priceFileName;
};
#endif // MAINWINDOW_H

