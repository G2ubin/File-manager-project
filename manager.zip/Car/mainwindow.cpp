#include "mainwindow.h"
#include "ui_mainwindow.h"
#include <QFile>
#include <QTextStream>
#include <QTableWidgetItem>
#include <QDebug>
#include <QSpinBox>
#include <QMessageBox>
#include <QFileDialog>
#include <QInputDialog>

MainWindow::MainWindow(QWidget *parent)
    : QMainWindow(parent),
    ui(new Ui::MainWindow)
{
    ui->setupUi(this);

    // -------------------------------------------------------
    this->showMaximized(); // Максимизируем окно приложения
    this->setMinimumSize(1400, 700);   // Минимальный размер окна
    // -------------------------------------------------------

    // ------------------------------------------------------------------------------------------
    // Фон приложения
    QString style = "QMainWindow { background-image: url(/Users/ta4her/Library/Mobile Documents/com~apple~CloudDocs/Documents/IT/c++/QT programms/back.png); }";
    this->setStyleSheet(style);
    // ------------------------------------------------------------------------------------------

    // ----------------------------------------------------------------------------------------------------------------------------------------
    // Устанавливаем стиль для qspinbox
    QString spinBoxStyle = "QSpinBox { background-color: #333333; color: #FFFFFF; border-radius: 5px; border: 1px solid #707e8a;}";
    ui->spinBoxMaxPrice->setStyleSheet(spinBoxStyle);
    ui->spinBoxMinPrice->setStyleSheet(spinBoxStyle);

    // Устанавливаем стиль для кнопок
    QString buttonStyle = "QPushButton { background-color: #707e8a; color: #FFFFFF; border: 1px solid #707e8a; border-radius: 10px;}"
                          "QPushButton:hover { background-color: #A9A9A9;  border: #707e8a; }";
    ui->pushButton->setStyleSheet(buttonStyle);
    ui->generateCarsByTypeButton->setStyleSheet(buttonStyle);
    ui->btnGenerateByPriceRange->setStyleSheet(buttonStyle);
    ui->CreateFile->setStyleSheet(buttonStyle);

    QString buttonLoadStyle = "QPushButton { background-color: #5A6B5D; color: #E1E1E1; border: 1px solid #5A6B5D; border-radius: 15px;}"
                              "QPushButton:hover { background-color: #328f6c;  border: #328f6c; }";
    ui->onLoadFile->setStyleSheet(buttonLoadStyle);

    // Устанавливаем стиль для таблицы
    QString tableStyle = "QTableWidget { background-color: #021E20;border: 1px solid #021E20; color: #CCD6D8;border-radius: 10px; }";
    ui->tableWidget->setStyleSheet(tableStyle);
    ui->manufacturerTable->setStyleSheet(tableStyle);
    ui->carsByTypeTable->setStyleSheet(tableStyle); // Добавление стилей для новой таблицы
    ui->carsByPriceRangeTable->setStyleSheet(tableStyle);

    // Устанавливаем стиль для поля ввода текста
    QString lineEditStyle = "QLineEdit { background-color: #333333; color: #FFFFFF; border-radius: 5px; }";
    ui->lineEdit->setStyleSheet(lineEditStyle);
    ui->lineEditBodyType->setStyleSheet(lineEditStyle);
    // ------------------------------------------------------------------------------------------------------------------------------------

    // -----------------------------------------------------------------------------
    // Устанавливаем количество столбцов для таблиц
    ui->tableWidget->setColumnCount(4);
    ui->manufacturerTable->setColumnCount(4); // Установите количество столбцов
    ui->carsByTypeTable->setColumnCount(4); // Установите количество столбцов
    ui->carsByPriceRangeTable->setColumnCount(4); // Установите количество столбцов
    // ---------------------------------------------------------------------------------
    // ------------------------------------------------------------------------------
    // Настройка ширины столбцов
    ui->tableWidget->horizontalHeader()->setSectionResizeMode(QHeaderView::Stretch);
    ui->manufacturerTable->horizontalHeader()->setSectionResizeMode(QHeaderView::Stretch);
    ui->carsByTypeTable->horizontalHeader()->setSectionResizeMode(QHeaderView::Stretch);
    ui->carsByPriceRangeTable->horizontalHeader()->setSectionResizeMode(QHeaderView::Stretch);
    // ------------------------------------------------------------------------------
    // -------------------------------------------------------
    // Устанавливаем заголовки столбцов
    QStringList headers;
    headers << "Марка" << "Фирма" << "Кузов" << "Цена";
    ui->tableWidget->setHorizontalHeaderLabels(headers);
    ui->manufacturerTable->setHorizontalHeaderLabels(headers);
    ui->carsByTypeTable->setHorizontalHeaderLabels(headers);
    ui->carsByPriceRangeTable->setHorizontalHeaderLabels(headers);
    // -------------------------------------------------------

    // -------------------------------------------------------
    // Включение сортировки таблиц
    ui->tableWidget->setSortingEnabled(true);
    ui->manufacturerTable->setSortingEnabled(true);
    ui->carsByTypeTable->setSortingEnabled(true);
    ui->carsByPriceRangeTable->setSortingEnabled(true);

    // Включаем режим редактирования
    ui->tableWidget->setEditTriggers(QAbstractItemView::DoubleClicked | QAbstractItemView::EditKeyPressed);
    ui->manufacturerTable->setEditTriggers(QAbstractItemView::NoEditTriggers);
    ui->carsByTypeTable->setEditTriggers(QAbstractItemView::NoEditTriggers);
    ui->carsByPriceRangeTable->setEditTriggers(QAbstractItemView::NoEditTriggers);
    // -------------------------------------------------------

    // --------------------------------------------------------------------------------------------
    ui->spinBoxMinPrice->setMinimum(0); // Устанавливаем минимальное значение
    ui->spinBoxMinPrice->setMaximum(1000000000); // Устанавливаем максимальное значение
    ui->spinBoxMaxPrice->setMinimum(0); // Устанавливаем минимальное значение
    ui->spinBoxMaxPrice->setMaximum(1000000000); // Устанавливаем максимальное значение
    // --------------------------------------------------------------------------------------------

    // --------------------------------------------------------------------------------------------
    // проверка на ввод числа в столбец цена
    connect(ui->tableWidget, &QTableWidget::itemChanged, this, &MainWindow::checkPriceInput);
    connect(ui->tableWidget, &QTableWidget::itemChanged, this, &MainWindow::checkTypeInput);
    // автоматическое сохранение главной татблицы
    connect(ui->tableWidget, &QTableWidget::cellChanged, this, &MainWindow::saveData);
    // Загрузка данных в таблицу
    connect(ui->onLoadFile, &QPushButton::clicked, this, &MainWindow::onLoadCustomDataButtonClicked);
    connect(ui->CreateFile, &QPushButton::clicked, this, &MainWindow::generateTable);
    // кнопки рядом с таблицами

    connect(ui->pushButton, &QPushButton::clicked, this, &MainWindow::selectFilePath);
    connect(ui->pushButton, &QPushButton::clicked, this, &MainWindow::generateFile);
    connect(ui->generateCarsByTypeButton, &QPushButton::clicked, this, &MainWindow::selectBodyTypeFilePath);
    connect(ui->generateCarsByTypeButton, &QPushButton::clicked, this, &MainWindow::generateCarsByType);
    connect(ui->btnGenerateByPriceRange, &QPushButton::clicked, this, &MainWindow::selectPriceFilePath);
    connect(ui->btnGenerateByPriceRange, &QPushButton::clicked, this, &MainWindow::generateCarsByPriceRange);
    // --------------------------------------------------------------------------------------------

    // Layout ------------------------------------------------------------------
    // Добавляем кнопки для добавления и удаления строк
    QPushButton *addRowButton = new QPushButton("Добавить строку", this);
    QPushButton *removeRowButton = new QPushButton("Удалить выбранную строку", this);

    connect(addRowButton, &QPushButton::clicked, this, &MainWindow::addRow);
    connect(removeRowButton, &QPushButton::clicked, this, &MainWindow::onRemoveRowButtonClicked);

    ui->verticalLayout->addWidget(addRowButton);
    ui->horizontalLayout->addWidget(removeRowButton);

    // --------------------------------------------------------------------------------
}

MainWindow::~MainWindow()
{
    delete ui;
}

// Функция для проверки ввода значений
void MainWindow::checkPriceInput(QTableWidgetItem *item)
{
    // Проверяем, что изменение произошло в столбце цен
    if (item && item->column() == 3) { // Предполагается, что столбец с ценой имеет индекс 3
        QString price = item->text();
        bool ok;
        price.toDouble(&ok);
        if (!ok) {
            // Выводим сообщение об ошибке и возвращаем предыдущее корректное значение
            QMessageBox::critical(this, "Ошибка", "Введено некорректное значение цены. Пожалуйста, введите число.");
            // Вернуть предыдущее корректное значение
            ui->tableWidget->blockSignals(true);
            item->setText(item->data(Qt::UserRole).toString()); // Установить предыдущее корректное значение
            ui->tableWidget->blockSignals(false);
        } else {
            // Если значение корректное, сохраняем его в качестве предыдущего значения
            item->setData(Qt::UserRole, price);
        }
    }
}

void MainWindow::checkTypeInput(QTableWidgetItem *item)
{
    // Проверяем, что изменение произошло в столбце типа кузова (предполагается, что индекс столбца с типом кузова равен 2)
    if (item && item->column() == 2) {
        QString type = item->text();
        // Проверяем, содержит ли строка число
        bool hasNumber = false;
        for (const QChar &ch : type) {
            if (ch.isDigit()) {
                hasNumber = true;
                break;
            }
        }
        // Если в строке есть число, выводим сообщение об ошибке и возвращаем предыдущее корректное значение
        if (hasNumber) {
            QMessageBox::critical(this, "Ошибка", "Введено некорректное значение. Тип кузова не может содержать числа.");
            ui->tableWidget->blockSignals(true);
            item->setText(item->data(Qt::UserRole).toString());
            ui->tableWidget->blockSignals(false);
        } else {
            // Если значение корректное, сохраняем его в качестве предыдущего значения
            item->setData(Qt::UserRole, type);
        }
    }
}

// Добавление строк в главную таблицу
void MainWindow::addRow()
{
    int row = ui->tableWidget->rowCount();
    ui->tableWidget->insertRow(row);
}
// Обработка нажатия кнопки удаления строки
void MainWindow::onRemoveRowButtonClicked()
{
    // Определяем, из какой таблицы была удалена строка
    QTableWidget *table = nullptr;
    if (ui->tableWidget->hasFocus()) {
        table = ui->tableWidget;
    }
    if (table) {
        // Получаем текущую выбранную ячейку
        QTableWidgetItem *item = table->currentItem();
        if (item) {
            // Удаляем строку, содержащую выбранную ячейку
            table->removeRow(item->row());
        } else {
             QMessageBox::warning(this, "Ошибка", "Ячейка не выбрана");
        }
    }
    saveData();
    Update();
    statusBar()->showMessage("Строка удалена!");
}
// Функция для сохранения данных
void MainWindow::saveData()
{
    // Получаем количество строк и столбцов в таблице
    int rowCount = ui->tableWidget->rowCount();
    int columnCount = ui->tableWidget->columnCount();
    // Проверяем, все ли ячейки таблицы заполнены
    for (int row = 0; row < rowCount; ++row) {
        for (int column = 0; column < columnCount; ++column) {
            QTableWidgetItem *item = ui->tableWidget->item(row, column);
            if (!item || item->text().isEmpty()) {
                // Если хотя бы одна ячейка пуста, выводим сообщение и завершаем функцию
                statusBar()->showMessage("Не все ячейки таблицы заполнены. Пожалуйста, заполните все ячейки перед сохранением.");
                return;
            }
        }
    }
    // Все ячейки таблицы заполнены, можно продолжать сохранение данных
    QFile file(currentFilePath);
    if (!file.open(QIODevice::WriteOnly | QIODevice::Text)) {
        return;
    }

    // Создаем поток для записи
    QTextStream out(&file);

    // Записываем данные из таблицы в файл
    for (int row = 0; row < rowCount; ++row) {
        for (int column = 0; column < columnCount; ++column) {
            // Получаем данные из ячейки таблицы
            QTableWidgetItem *item = ui->tableWidget->item(row, column);
            QString data = (item ? item->text() : "");
            out << data;
            if (column < columnCount - 1) {
                out << ";"; // Разделитель между данными
            }
        }
        out << "\n"; // Переход на новую строку после записи всех данных из строки
    }
    // Закрываем файл
    file.close();
    statusBar()->showMessage("Данные сохранены успешно!");
    Update();
}
// Кнопка для загрузки данных в таблицу
void MainWindow::onLoadCustomDataButtonClicked()
{
    QString defaultDir = "/Users/ta4her/Library/Mobile Documents/com~apple~CloudDocs/Documents/IT/c++/QT programms/";
    QString filePath = QFileDialog::getOpenFileName(this, tr("Открыть файл"), defaultDir, tr("Текстовые файлы (*.txt);;Все файлы (*)"));
    if (!filePath.isEmpty()) {
        loadData(filePath);
    }
}
// обновление данных
void MainWindow::Update() {
    // Очищаем таблицу перед загрузкой новых данных
    ui->manufacturerTable->clearContents();
    ui->manufacturerTable->setRowCount(0); // Устанавливаем количество строк в 0

    ui->carsByTypeTable->clearContents();
    ui->carsByTypeTable->setRowCount(0); // Устанавливаем количество строк в 0

    ui->carsByPriceRangeTable->clearContents();
    ui->carsByPriceRangeTable->setRowCount(0); // Устанавливаем количество строк в 0

    generateFile();
    generateCarsByType();
    generateCarsByPriceRange();
}


void MainWindow::generateTable()
{
    QString defaultDir = "/Users/ta4her/Library/Mobile Documents/com~apple~CloudDocs/Documents/IT/c++/QT programms/";
    QString fileName = QFileDialog::getSaveFileName(this, tr("Создать новый файл"), defaultDir, tr("Text Files (*.txt);;All Files (*)"));

    if (!fileName.isEmpty()) {
        QFile file(fileName);
        if (file.open(QIODevice::WriteOnly | QIODevice::Text)) {
            // Создаем поток для записи
            QTextStream out(&file);

            file.close();
            // После создания файла открываем его для редактирования
            loadData(fileName);
        }
    }
    ui->tableWidget->clearContents();
    ui->tableWidget->setRowCount(0); // Устанавливаем количество строк в 0
}

void MainWindow::generateFile()
{
    if (ui->lineEdit->text().isEmpty()) {
        // Если поле lineEdit пустое, просто выходим из функции
        return;
    }
    QString manufacturer = ui->lineEdit->text(); // Получаем название фирмы из QLineEdit
    if (manufacturerFileName.isEmpty()) {
        // Если пользователь отменил выбор, просто выходим из функции
        return;
    }
    // Открываем файл для записи
    QFile outputFile(manufacturerFileName);
    if (!outputFile.open(QIODevice::WriteOnly | QIODevice::Text)) {
        qDebug() << "Failed to open output file. Error: " << outputFile.errorString();
        return;
    }

    // Создаем поток для записи
    QTextStream out(&outputFile);

    // Открываем файл auto.txt для чтения
    QFile inputFile(currentFilePath);
    if (!inputFile.open(QIODevice::ReadOnly | QIODevice::Text)) {
        qDebug() << "Failed to open input file. Error: " << inputFile.errorString();
        outputFile.close();
        return;
    }

    // Читаем данные из файла и записываем только те, которые соответствуют введенной фирме
    QTextStream in(&inputFile);
    while (!in.atEnd()) {
        QString line = in.readLine();
        QStringList parts = line.split(';');
        if (parts.size() >= 2 && parts[1] == manufacturer) {
            out << line << '\n';
        }
    }

    // Закрываем файлы
    inputFile.close();
    outputFile.close();

    ui->manufacturerTable->clearContents();
    ui->manufacturerTable->setRowCount(0); // Устанавливаем количество строк в 0

    // Передаем имя файла в функцию загрузки данных
    loadDataFile(manufacturerFileName, ui->manufacturerTable);
}

void MainWindow::generateCarsByType()
{
    if (ui->lineEditBodyType->text().isEmpty()) {
        // Если поле lineEdit пустое, просто выходим из функции
        return;
    }
    QString bodyType = ui->lineEditBodyType->text(); // Получаем тип кузова из QLineEdit

    if (bodyTypeFileName.isEmpty()) {
        // Если пользователь отменил выбор, просто выходим из функции
        return;
    }
    // Открываем файл для записи
    QFile outputFile(bodyTypeFileName);
    if (!outputFile.open(QIODevice::WriteOnly | QIODevice::Text)) {
        qDebug() << "Failed to open output file. Error: " << outputFile.errorString();
        return;
    }

    // Создаем поток для записи
    QTextStream out(&outputFile);

    // Открываем файл auto.txt для чтения
    QFile inputFile(currentFilePath);
    if (!inputFile.open(QIODevice::ReadOnly | QIODevice::Text)) {
        qDebug() << "Failed to open input file. Error: " << inputFile.errorString();
        outputFile.close();
        return;
    }

    // Читаем данные из файла и записываем только те, которые соответствуют введенному типу кузова
    QTextStream in(&inputFile);
    while (!in.atEnd()) {
        QString line = in.readLine();
        QStringList parts = line.split(';');
        if (parts.size() >= 3 && parts[2] == bodyType) {
            out << line << '\n';
        }
    }

    // Закрываем файлы
    inputFile.close();
    outputFile.close();

    ui->carsByTypeTable->clearContents();
    ui->carsByTypeTable->setRowCount(0); // Устанавливаем количество строк в 0
    loadDataFile(bodyTypeFileName, ui->carsByTypeTable);
}

void MainWindow::generateCarsByPriceRange() {
    // Проверяем, равно ли значение spinBox нулю
    if (ui->spinBoxMinPrice->value() == 0) {
        if (ui->spinBoxMaxPrice->value() == 0) {
            return;
        }
    }
    int minPrice = ui->spinBoxMinPrice->value();
    int maxPrice = ui->spinBoxMaxPrice->value();

    // Открываем файл для записи
    QFile outputFile(priceFileName);
    if (!outputFile.open(QIODevice::WriteOnly | QIODevice::Text)) {
        qDebug() << "Failed to open output file. Error: " << outputFile.errorString();
        return;
    }

    // Создаем поток для записи
    QTextStream out(&outputFile);

    // Открываем файл auto.txt для чтения
    QFile inputFile(currentFilePath);
    if (!inputFile.open(QIODevice::ReadOnly | QIODevice::Text)) {
        qDebug() << "Failed to open input file. Error: " << inputFile.errorString();
        outputFile.close();
        return;
    }

    // Читаем данные из файла и записываем только те, которые соответствуют введенному диапазону цен
    QTextStream in(&inputFile);
    while (!in.atEnd()) {
        QString line = in.readLine();
        QStringList parts = line.split(';');
        if (parts.size() >= 4) { // Проверяем, что строка содержит четыре значения
            double carPrice = parts[3].toDouble();
            if (carPrice >= minPrice && carPrice <= maxPrice) { // Проверяем, что цена входит в диапазон
                out << line << '\n';
            }
        }
    }

    // Закрываем файлы
    inputFile.close();
    outputFile.close();

    ui->carsByPriceRangeTable->clearContents();
    ui->carsByPriceRangeTable->setRowCount(0); // Устанавливаем количество строк в 0

    loadDataFile(priceFileName, ui->carsByPriceRangeTable);
}


void MainWindow::loadData(const QString &filePath)
{
    currentFilePath = filePath; // Сохраняем путь к файлу
    QFile file(filePath);
    if (!file.open(QIODevice::ReadOnly | QIODevice::Text)) {
        qDebug() << "Failed to open file. Error: " << file.errorString();
        return;
    }
    QTextStream in(&file);
    int rowCount = 0;
    while (!in.atEnd()) {
        in.readLine();
        rowCount++;
    }
    file.seek(0);
    ui->tableWidget->setRowCount(rowCount);

    int row = 0;
    while (!in.atEnd() && row < rowCount) {
        QString line = in.readLine();
        QStringList parts = line.split(';');
        for (int col = 0; col < parts.size(); ++col) {
            QTableWidgetItem *item = new QTableWidgetItem(parts[col]);
            ui->tableWidget->setItem(row, col, item);
        }
        ++row;
    }

    file.close();
}

void MainWindow::loadDataFile(const QString &fileName, QTableWidget *tableWidget) {
    QFile file(fileName);
    if (!file.open(QIODevice::ReadOnly | QIODevice::Text)) {
        qDebug() << "Failed to open file. Error: " << file.errorString();
        return;
    }

    QTextStream in(&file);
    int row = 0;
    while (!in.atEnd()) {
        QString line = in.readLine();
        QStringList parts = line.split(';');
        if (parts.size() == 4) { // Проверяем, что строка содержит четыре значения
            tableWidget->insertRow(row);
            for (int col = 0; col < parts.size(); ++col) {
                QTableWidgetItem *item = new QTableWidgetItem(parts[col]);
                tableWidget->setItem(row, col, item);
            }
            ++row;
        }
    }

    file.close();
}

// Функция selectFilePath для выбора пути файла
void MainWindow::selectFilePath() {
    // Открываем диалоговое окно для выбора пути файла
    QString defaultDir = "/Users/ta4her/Library/Mobile Documents/com~apple~CloudDocs/Documents/IT/c++/QT programms/";
    QString newFileName = QFileDialog::getSaveFileName(this, tr("Выберите место сохранения файла"), defaultDir + "manufacturer_cars.txt", tr("Text Files (*.txt);;All Files (*)"));
    if (!newFileName.isEmpty()) {
        // Если пользователь выбрал файл, сохраняем его путь
        manufacturerFileName = newFileName;
    }
}
// Функция для выбора пути файла для типа кузова
void MainWindow::selectBodyTypeFilePath() {
    QString defaultDir = "/Users/ta4her/Library/Mobile Documents/com~apple~CloudDocs/Documents/IT/c++/QT programms/";
    QString newFileName = QFileDialog::getSaveFileName(this, tr("Выберите место сохранения файла для типа кузова"), defaultDir + "body_type.txt", tr("Text Files (*.txt);;All Files (*)"));
    if (!newFileName.isEmpty()) {
        bodyTypeFileName = newFileName;
    }
}
// Функция для выбора пути файла для цены
void MainWindow::selectPriceFilePath() {
    QString defaultDir = "/Users/ta4her/Library/Mobile Documents/com~apple~CloudDocs/Documents/IT/c++/QT programms/";
    QString newFileName = QFileDialog::getSaveFileName(this, tr("Выберите место сохранения файла для цены"), defaultDir + "price.txt", tr("Text Files (*.txt);;All Files (*)"));
    if (!newFileName.isEmpty()) {
        priceFileName = newFileName;
    }
}
