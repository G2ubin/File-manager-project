#include "mainwindow.h"
#include <QApplication>


int main(int argc, char *argv[])
{
    QApplication a(argc, argv);

    // Создаем объект MainWindow
    MainWindow w;
    w.setWindowTitle("Car Manager");

    // Устанавливаем иконку приложения
    QIcon appIcon("/Users/ta4her/Library/Mobile Documents/com~apple~CloudDocs/Documents/IT/c++/QT programms/FinderBigSur.png");
    a.setWindowIcon(appIcon);

    // Показываем главное окно
    w.show();

    // Запускаем главный цикл обработки событий приложения
    return a.exec();
}
